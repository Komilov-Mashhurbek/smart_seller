package com.example.smart_seller;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Hisoblash1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hisoblash1);
    }
}